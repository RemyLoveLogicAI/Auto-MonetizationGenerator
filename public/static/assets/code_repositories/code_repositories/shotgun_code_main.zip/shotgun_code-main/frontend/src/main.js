import {createApp} from 'vue'
import App from './App.vue'
import './assets/main.css' // Basic styles

createApp(App).mount('#app')
